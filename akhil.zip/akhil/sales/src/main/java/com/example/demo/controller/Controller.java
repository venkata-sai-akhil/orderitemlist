package com.example.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.PurchaseOrders;
import com.example.demo.Repository.Repository;
@RestController
public class Controller {
	
	@Autowired
	private Repository re ;
	@PostMapping(value="/save")

	 private String saveEmp(@RequestBody PurchaseOrders c)

	 {

	  re.save(c);

	 return "inserted successfully";

	 }
}
