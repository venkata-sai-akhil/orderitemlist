package com.example.demo.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.PurchaseOrders;

public interface Repository extends JpaRepository<PurchaseOrders, Integer>{
	

}
